# Configuración de la base de datos

El proyecto utiliza una base de datos **MySQL local** y se conecta mediante Hibernate/JPA.

Antes de ejecutar el proyecto, es necesario configurar el usuario y la contraseña de MySQL en:

`src/main/resources/META-INF/persistence.xml`

Dentro de `<properties>` se deben modificar:

```xml
<property name="jakarta.persistence.jdbc.user" value="root"/>
<property name="jakarta.persistence.jdbc.password" value="root"/>
```

Se deben reemplazar los valores `root` por el usuario y contraseña configurados en la instalación local de MySQL.

La base de datos **facturacion** no necesita crearse manualmente, ya que el proyecto está configurado para crearla automáticamente si no existe. Las tablas también son generadas y actualizadas automáticamente por Hibernate.

Si MySQL utiliza un puerto diferente al `3306`, también se debe modificar la URL de conexión:

```xml
<property name="jakarta.persistence.jdbc.url"
          value="jdbc:mysql://localhost:3306/facturacion?createDatabaseIfNotExist=true"/>
```

En este caso, se reemplaza `3306` por el puerto correspondiente.

