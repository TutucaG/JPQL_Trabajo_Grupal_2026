package org.example;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.example.entidades.Articulo;
import org.example.entidades.Cliente;
import org.example.entidades.FacturaVenta;
import org.example.entidades.PuntoVenta;
import org.example.entidades.FacturaVentaDetalle;
import org.example.entidades.Marca;
import java.util.Date;
import java.util.List;

public class ResolucionConsultas {
    private EntityManager em;

    public ResolucionConsultas(EntityManager em) {
        this.em = em;
    }

    public void ejecutarNivel1() {
        System.out.println("========== NIVEL 1 ==========");

        // --- Consigna 1 ---
        System.out.println("\n1. Entidades Completas:");
        String jpql1 = "SELECT f FROM FacturaVenta f";
        TypedQuery query1 = em.createQuery(jpql1, FacturaVenta.class);
        List c1 = query1.getResultList();

        for (int i = 0; i < c1.size(); i++) {
            FacturaVenta f = (FacturaVenta) c1.get(i);
            System.out.println("Factura Nro: " + f.getNumero());
        }

        // --- Consigna 2 ---
        System.out.println("\n2. Proyección de Atributos:");
        String jpql2 = "SELECT f.numero, f.fechaEmision, f.importeTotal FROM FacturaVenta f";
        TypedQuery query2 = em.createQuery(jpql2, Object[].class);
        List c2 = query2.getResultList();

        for (int i = 0; i < c2.size(); i++) {
            Object[] fila = (Object[]) c2.get(i);
            System.out.println("Nro: " + fila[0] + ", Fecha: " + fila[1] + ", Total: $" + fila[2]);
        }

        // --- Consigna 3 ---
        System.out.println("\n3. Filtrado por Igualdad (WHERE):");
        String jpql3 = "SELECT a FROM Articulo a WHERE a.rubro.denominacion = :nombreRubro";
        TypedQuery query3 = em.createQuery(jpql3, Articulo.class);
        query3.setParameter("nombreRubro", "Bebidas");
        List c3 = query3.getResultList();

        for (int i = 0; i < c3.size(); i++) {
            Articulo a = (Articulo) c3.get(i);
            System.out.println("Artículo: " + a.getDenominacion());
        }

        // --- Consigna 4 ---
        System.out.println("\n4. Filtrado por Rango de Fechas (BETWEEN):");
        String jpql4 = "SELECT f FROM FacturaVenta f WHERE f.fechaEmision BETWEEN :fechaInicio AND :fechaFin";

        Date fechaInicio = new Date(System.currentTimeMillis() - (1000 * 60 * 60 * 24));
        Date fechaFin = new Date(System.currentTimeMillis() + (1000 * 60 * 60 * 24));

        TypedQuery query4 = em.createQuery(jpql4, FacturaVenta.class);
        query4.setParameter("fechaInicio", fechaInicio);
        query4.setParameter("fechaFin", fechaFin);
        List c4 = query4.getResultList();

        for (int i = 0; i < c4.size(); i++) {
            FacturaVenta f = (FacturaVenta) c4.get(i);
            System.out.println("Factura en rango: Nro " + f.getNumero());
        }
    }

    public void ejecutarNivel2() {
        System.out.println("\n========== NIVEL 2 ==========");

        // --- Consigna 5 ---
        System.out.println("\n5. Condicionales Complejos y Verificación de Nulos:");
        String jpql5 = "SELECT f FROM FacturaVenta f WHERE f.estado = :estado AND f.importeTotal > :importe AND f.fechaAnulacion IS NULL";
        TypedQuery query5 = em.createQuery(jpql5, FacturaVenta.class);
        query5.setParameter("estado", "EMITIDA");
        query5.setParameter("importe", 10000.0);
        List c5 = query5.getResultList();

        if (c5.isEmpty()) {
            System.out.println("Resultado: No hay facturas que superen los $10.000 con los criterios dados.");
        } else {
            for (int i = 0; i < c5.size(); i++) {
                FacturaVenta f = (FacturaVenta) c5.get(i);
                System.out.println("Factura Nro: " + f.getNumero());
            }
        }

        // --- Consigna 6 ---
        System.out.println("\n6. Búsqueda por Patrón de Texto (LIKE y LOWER):");
        String jpql6 = "SELECT c FROM Cliente c WHERE LOWER(c.denominacion) LIKE LOWER(:texto) OR c.cuitCuil LIKE :prefijoCuit";
        TypedQuery query6 = em.createQuery(jpql6, Cliente.class);
        query6.setParameter("texto", "%consumidor%");
        query6.setParameter("prefijoCuit", "20-%");
        List c6 = query6.getResultList();

        for (int i = 0; i < c6.size(); i++) {
            Cliente c = (Cliente) c6.get(i);
            System.out.println("Cliente: " + c.getDenominacion() + " (CUIT: " + c.getCuitCuil() + ")");
        }

        // --- Consigna 7 ---
        System.out.println("\n7. Valores Distintos y Ordenamiento:");
        String jpql7 = "SELECT DISTINCT f.estado FROM FacturaVenta f ORDER BY f.estado ASC";
        TypedQuery query7 = em.createQuery(jpql7, String.class);
        List c7 = query7.getResultList();

        for (int i = 0; i < c7.size(); i++) {
            String estado = (String) c7.get(i);
            System.out.println("Estado Registrado: " + estado);
        }

        // --- Consigna 8 ---
        System.out.println("\n8. Funciones de Agregación Simples:");
        String jpql8 = "SELECT COUNT(f), SUM(f.importeTotal), AVG(f.importeTotal) FROM FacturaVenta f";
        TypedQuery query8 = em.createQuery(jpql8, Object[].class);
        List c8 = query8.getResultList();

        for (int i = 0; i < c8.size(); i++) {
            Object[] agregacion = (Object[]) c8.get(i);
            System.out.println("Cantidad Emitida: " + agregacion[0]);
            System.out.println("Suma Total: $" + agregacion[1]);
            System.out.println("Promedio: $" + agregacion[2]);
        }

        // --- Consigna 9 ---
        System.out.println("\n9. Operador de Inclusión (IN):");
        String jpql9 = "SELECT p FROM PuntoVenta p WHERE p.numero IN :listaNumeros";
        TypedQuery query9 = em.createQuery(jpql9, PuntoVenta.class);
        query9.setParameter("listaNumeros", java.util.Arrays.asList(1, 2, 5));
        List c9 = query9.getResultList();

        for (int i = 0; i < c9.size(); i++) {
            PuntoVenta p = (PuntoVenta) c9.get(i);
            System.out.println("Punto de Venta Nro: " + p.getNumero() + " - " + p.getDescripcion());
        }
    }
    public void ejecutarNivel3() {
        System.out.println("\n========== NIVEL 3 ==========");

        // --- Consigna 10 ---
        System.out.println("\n10. Navegación Implícita por Relaciones:");
        String jpql10 = "SELECT f FROM FacturaVenta f WHERE f.usuarioCarga.usuario = :usuario";
        TypedQuery query10 = em.createQuery(jpql10, FacturaVenta.class);
        query10.setParameter("usuario", "admin");
        List c10 = query10.getResultList();
        for (int i = 0; i < c10.size(); i++) {
            FacturaVenta f = (FacturaVenta) c10.get(i);
            System.out.println("Factura Nro: " + f.getNumero() + " cargada por " + f.getUsuarioCarga().getUsuario());
        }

        // --- Consigna 11 ---
        System.out.println("\n11. Cláusula INNER JOIN Explícita:");
        String jpql11 = "SELECT d FROM FacturaVentaDetalle d JOIN d.factura f WHERE f.puntoVenta.numero = :numeroPuntoVenta";
        TypedQuery query11 = em.createQuery(jpql11, FacturaVentaDetalle.class);
        query11.setParameter("numeroPuntoVenta", 1);
        List c11 = query11.getResultList();
        for (int i = 0; i < c11.size(); i++) {
            FacturaVentaDetalle d = (FacturaVentaDetalle) c11.get(i);
            System.out.println("Detalle: " + d.getDescripcion() + " - Factura Nro: " + d.getFactura().getNumero());
        }

        // --- Consigna 12 ---
        System.out.println("\n12. Cláusula LEFT JOIN (Inclusión de Nulos):");
        String jpql12 = "SELECT a.denominacion, m.denominacion FROM Articulo a LEFT JOIN a.marca m";
        TypedQuery query12 = em.createQuery(jpql12, Object[].class);
        List c12 = query12.getResultList();
        for (int i = 0; i < c12.size(); i++) {
            Object[] fila = (Object[]) c12.get(i);
            String marcaDenom = fila[1] != null ? (String) fila[1] : "Sin Marca";
            System.out.println("Artículo: " + fila[0] + " - Marca: " + marcaDenom);
        }

        // --- Consigna 13 ---
        System.out.println("\n13. Navegación Multinivel con JOINs Combinados:");
        String jpql13 = "SELECT DISTINCT f FROM FacturaVenta f " +
                "JOIN f.detalles d " +
                "JOIN d.listaPrecioArticulo lpa " +
                "JOIN lpa.articulo a " +
                "JOIN a.marca m " +
                "WHERE m.denominacion = :nombreMarca";

        String jpql13bis = "SELECT DISTINCT f FROM FacturaVenta f " +
                "JOIN f.detalles d " +
                "WHERE d.listaPrecioArticulo.articulo.marca.denominacion = :nombreMarca";

        TypedQuery query13 = em.createQuery(jpql13, FacturaVenta.class);
        query13.setParameter("nombreMarca", "Coca-Cola");
        List c13 = query13.getResultList();
        for (int i = 0; i < c13.size(); i++) {
            FacturaVenta f = (FacturaVenta) c13.get(i);
            System.out.println("Factura vinculada a la marca: Nro " + f.getNumero());
        }

        // --- Consigna 14 ---
        System.out.println("\n14. Subconsulta en Cláusula WHERE:");
        String jpql14 = "SELECT f FROM FacturaVenta f WHERE f.importeTotal > (SELECT AVG(f2.importeTotal) FROM FacturaVenta f2)";
        TypedQuery query14 = em.createQuery(jpql14, FacturaVenta.class);
        List c14 = query14.getResultList();
        if (c14.isEmpty()) {
            System.out.println("No hay facturas que superen el promedio general.");
        } else {
            for (int i = 0; i < c14.size(); i++) {
                FacturaVenta f = (FacturaVenta) c14.get(i);
                System.out.println("Factura por encima del promedio: Nro " + f.getNumero() + " ($" + f.getImporteTotal() + ")");
            }
        }
    }

    public void ejecutarNivel4() {
        System.out.println("\n========== NIVEL 4 ==========");

        // --- Consigna 15 ---
        System.out.println("\n15. Agrupamiento Básico (GROUP BY):");
        String jpql15 = "SELECT f.puntoVenta.descripcion, COUNT(f), SUM(f.importeTotal) FROM FacturaVenta f GROUP BY f.puntoVenta.descripcion";
        TypedQuery query15 = em.createQuery(jpql15, Object[].class);
        List c15 = query15.getResultList();
        for (int i = 0; i < c15.size(); i++) {
            Object[] fila = (Object[]) c15.get(i);
            System.out.println("Punto de Venta: " + fila[0] + " | Cantidad: " + fila[1] + " | Total Facturado: $" + fila[2]);
        }

        // --- Consigna 16 ---
        System.out.println("\n16. Agrupamiento con Condicional de Grupo (HAVING):");
        String jpql16 = "SELECT f.usuarioCarga.usuario FROM FacturaVenta f GROUP BY f.usuarioCarga.usuario HAVING COUNT(f) > :cantidadMinima";
        TypedQuery query16 = em.createQuery(jpql16, String.class);
        query16.setParameter("cantidadMinima", 5L);
        List c16 = query16.getResultList();
        if (c16.isEmpty()) {
            System.out.println("Ningún usuario registró más de 5 facturas.");
        } else {
            for (int i = 0; i < c16.size(); i++) {
                String usuario = (String) c16.get(i);
                System.out.println("Usuario con alta carga: " + usuario);
            }
        }

        // --- Consigna 17 ---
        System.out.println("\n17. Agrupamiento y Agregación sobre Entidades Relacionadas:");
        String jpql17 = "SELECT m.denominacion, SUM(d.cantidad), SUM(d.importeSubtotal) FROM FacturaVentaDetalle d JOIN d.listaPrecioArticulo lpa JOIN lpa.articulo a JOIN a.marca m GROUP BY m.denominacion";
        TypedQuery query17 = em.createQuery(jpql17, Object[].class);
        List c17 = query17.getResultList();
        for (int i = 0; i < c17.size(); i++) {
            Object[] fila = (Object[]) c17.get(i);
            System.out.println("Marca: " + fila[0] + " | Unidades: " + fila[1] + " | Subtotal: $" + fila[2]);
        }
    }

    public void ejecutarNivel5() {
        System.out.println("\n========== NIVEL 5 ==========");

        // --- Consigna 18 ---
        System.out.println("\n18. Subconsulta Correlacionada con EXISTS:");
        String jpql18 = "SELECT m FROM Marca m WHERE EXISTS (SELECT d FROM FacturaVentaDetalle d JOIN d.listaPrecioArticulo lpa JOIN lpa.articulo a WHERE a.marca = m)";
        TypedQuery query18 = em.createQuery(jpql18, Marca.class);
        List c18 = query18.getResultList();
        for (int i = 0; i < c18.size(); i++) {
            Marca m = (Marca) c18.get(i);
            System.out.println("Marca con ventas registradas: " + m.getDenominacion());
        }

        // --- Consigna 19 ---
        System.out.println("\n19. Subconsulta Correlacionada con NOT EXISTS:");
        String jpql19 = "SELECT a FROM Articulo a WHERE NOT EXISTS (SELECT d FROM FacturaVentaDetalle d JOIN d.listaPrecioArticulo lpa WHERE lpa.articulo = a)";
        TypedQuery query19 = em.createQuery(jpql19, Articulo.class);
        List c19 = query19.getResultList();
        if (c19.isEmpty()) {
            System.out.println("Todos los artículos han sido facturados al menos una vez.");
        } else {
            for (int i = 0; i < c19.size(); i++) {
                Articulo a = (Articulo) c19.get(i);
                System.out.println("Artículo sin ventas: " + a.getDenominacion());
            }
        }

        // --- Consigna 20 ---
        System.out.println("\n20. Proyección Condicional (CASE WHEN):");
        String jpql20 = "SELECT f.numero, f.importeTotal, CASE " +
                "WHEN f.importeTotal > 50000 THEN 'ALTO VALOR' " +
                "WHEN f.importeTotal BETWEEN 10000 AND 50000 THEN 'MEDIO VALOR' " +
                "ELSE 'BAJO VALOR' END " +
                "FROM FacturaVenta f ORDER BY f.importeTotal DESC";
        TypedQuery query20 = em.createQuery(jpql20, Object[].class);
        List c20 = query20.getResultList();
        for (int i = 0; i < c20.size(); i++) {
            Object[] fila = (Object[]) c20.get(i);
            System.out.println("Factura Nro " + fila[0] + " | Total: $" + fila[1] + " | Categoría: " + fila[2]);
        }
    }
}