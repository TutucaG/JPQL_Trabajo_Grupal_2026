package org.example;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class Main {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("FacturacionPU");
        EntityManager em = emf.createEntityManager();

        try {
            // Instanciamos la clase de resolución
            ResolucionConsultas resolucion = new ResolucionConsultas(em);

            // Ejecutamos las consultas
            resolucion.ejecutarNivel1();
            resolucion.ejecutarNivel2();
            resolucion.ejecutarNivel3();
            resolucion.ejecutarNivel4();
            resolucion.ejecutarNivel5();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            em.close();
            emf.close();
        }
    }

}